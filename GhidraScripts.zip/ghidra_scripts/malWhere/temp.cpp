#include <iostream>
using namespace std;

int main() {
    int a, b;
    cin >> a >> b;
    cout << "The sum of " << a << " and " << b << " is " << a + b << "." << endl;
    return 0;
}
/*
run: ./fuzz
*/